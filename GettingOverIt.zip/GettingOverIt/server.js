const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const session = require('express-session');

//Connect to PostgreSQL using knex
const knex = require('knex')({
  client: 'pg',
  connection: {
    host: '127.0.0.1',
    user: 'postgres',
    password: 'newpassword123',
    database: 'loginform'
  }
});

const app = express();
const initialPath = path.join(__dirname, 'public');

//Middleware
app.use(bodyParser.json());
app.use(express.static(initialPath));
app.use(session({
  secret: 'your-secret-key',
  resave: false,
  saveUninitialized: false,
  cookie: { secure: false }
}));

//Serve static pages
app.get('/', (req, res) => res.sendFile(path.join(initialPath, 'index.html')));
app.get('/login', (req, res) => res.sendFile(path.join(initialPath, 'login.html')));
app.get('/signup', (req, res) => res.sendFile(path.join(initialPath, 'signup.html')));
app.get('/goalSetter.html', (req, res) => res.sendFile(path.join(initialPath, 'goalSetter.html')));
app.get('/dailyTracker.html', (req, res) => res.sendFile(path.join(initialPath, 'dailyTracker.html')));

//Signup
app.post('/signup', async (req, res) => {
  const { firstname, email, password } = req.body;

  try {
    const existing = await knex('users').where({ email }).first();
    if (existing) return res.status(400).json({ error: 'Email already registered' });

    await knex('users').insert({ firstname, email, password });
    res.status(200).json({ message: 'Signup successful' });
  } catch (err) {
    console.error('SIGNUP ERROR:', err);
    res.status(500).json({ error: 'Server error during signup' });
  }
});

//Login
app.post('/login', async (req, res) => {
  const { email, password } = req.body;

  try {
    const user = await knex('users').where({ email }).first();
    if (!user || user.password !== password) {
      return res.status(401).json({ error: 'Invalid email or password' });
    }

    req.session.userId = user.id;
    res.status(200).json({ message: 'Login successful' });
  } catch (err) {
    console.error('LOGIN ERROR:', err);
    res.status(500).json({ error: 'Server error during login' });
  }
});

//Save journal entry (limit 1 per day)
app.post('/journal', async (req, res) => {
  const userId = req.session.userId;
  const { content } = req.body;
  const today = new Date().toISOString().split('T')[0];

  if (!userId) return res.status(401).json({ error: 'User not logged in' });

  try {
    const existing = await knex('journal_entries')
      .where({ user_id: userId, entry_date: today })
      .first();

    if (existing) {
      return res.status(400).json({ error: 'Journal entry already submitted today' });
    }

    await knex('journal_entries').insert({ user_id: userId, content });
    res.status(200).json({ message: 'Entry saved' });
  } catch (err) {
    console.error('JOURNAL SAVE ERROR:', err);
    res.status(500).json({ error: 'Could not save journal entry' });
  }
});

//View journal entry by date
app.get('/journal', async (req, res) => {
  const userId = req.session.userId;
  const { date } = req.query;

  if (!userId) return res.status(401).json({ error: 'Not logged in' });
  if (!date) return res.status(400).json({ error: 'Date is required' });

  try {
    const entry = await knex('journal_entries')
      .where({ user_id: userId, entry_date: date })
      .first();

    res.status(200).json({ content: entry ? entry.content : null });
  } catch (err) {
    console.error('JOURNAL FETCH ERROR:', err);
    res.status(500).json({ error: 'Failed to fetch journal entry' });
  }
});

//Sobriety counter - get current count
app.get('/sobriety', async (req, res) => {
  const userId = req.session.userId;
  if (!userId) return res.status(401).json({ error: 'Not logged in' });

  try {
    const record = await knex('sobriety_tracker').where({ user_id: userId }).first();
    res.json({ days: record ? record.day_count : 0 });
  } catch (err) {
    console.error('GET SOBRIETY ERROR:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Sobriety counter - increment once per day
app.post('/sobriety', async (req, res) => {
  const userId = req.session.userId;
  if (!userId) return res.status(401).json({ error: 'Not logged in' });

  const today = new Date().toISOString().split('T')[0];

  try {
    let tracker = await knex('sobriety_tracker').where({ user_id: userId }).first();

    if (!tracker) {
      await knex('sobriety_tracker').insert({
        user_id: userId,
        day_count: 1,
        last_increment_date: today
      });
      return res.status(200).json({ message: 'Day 1 logged. Keep going!' });
    }

    if (tracker.last_increment_date === today) {
      return res.status(400).json({ error: 'Already incremented today' });
    }

    await knex('sobriety_tracker')
      .where({ user_id: userId })
      .update({
        day_count: tracker.day_count + 1,
        last_increment_date: today
      });

    res.status(200).json({ message: `Day ${tracker.day_count + 1} logged! Keep it up!` });
  } catch (err) {
    console.error('SOBRIETY UPDATE ERROR:', err);
    res.status(500).json({ error: 'Could not update day count' });
  }
});

//Logout
app.post('/logout', (req, res) => {
  req.session.destroy(() => {
    res.status(200).json({ message: 'Logged out' });
  });
});

//Session check
app.get('/me', async (req, res) => {
  if (!req.session.userId) return res.status(200).json({ loggedIn: false });

  const user = await knex('users').where({ id: req.session.userId }).first();
  if (user) {
    res.status(200).json({ loggedIn: true, firstname: user.firstname });
  } else {
    res.status(200).json({ loggedIn: false });
  }
});

//Start server
app.listen(3000, () => {
  console.log('Server running at http://localhost:3000');
});
