#I used this website to aquire more information about the math module in Python
#https://www.w3schools.com/python/module_math.asp
import math

#Function to diplay menu to the user
def menu():
    print("\nMenu")
    print("------")
    print("R - Rules")
    print("E - Enter Equation")
    print("D - Done")

#Function to display rules to the user
def rules():
    print("RULES\n-----\n1. All math will follow basic PEMDAS if order of calculation is not specified with parentheses.\n2. The variable 'a' (must be lowercase) will act as the recursive call to the sequence and use the output of the last iteration of the sequence as its value.\n3. The variable 'n' (must be lowercase) will represent the current iteration number.\nArithmetic Syntax\n-----------------\n1. Addition: +\n2. Subtraction: -\n3. Multiplication: *\n4. Division: /\n5. Exponentiation: **\n6. Factorial: factorial(n or #)\n7. Trigonometric Functions: sin(n), cos(n), tan(n), asin(n), acos(n), atan(n)\n8. Logs: log(n) (natural logarithm)\n9. Pi: (pi)\n10. e: (e)")


#Function to evaluate the given expression with a and n included
def evaluate_expression(expression, n, a):
    try:
        #Pass functions and constants
        result = eval(expression, {
            #All trig functions, factorial, and log using math library
            'math': math, #Refers to the math module
            'sin': math.sin, #Sin
            'cos': math.cos, #Cos
            'tan': math.tan, #Tan
            'asin': math.asin, #Arcsin
            'acos': math.acos, #Arccos
            'atan': math.atan, #Arctan
            'log': math.log, #log
            'factorial': math.factorial, #factorial
            'pi': math.pi, #pi
            'e': math.e #e
        }, {
            'n': n, #Current iteration
            'a': a, #Previous answer
        })
        return result
    except Exception as e:
        #Handle errors if there are errors during evaluating the give equations
        print(f"Error evaluating expression: {e}")
        return None

#Function to calculate and display the sequence
def do():
    print("\nEnter the sequence equation. Use 'a' for the previous term and 'n' for the iteration number.") #Prompt user for equation
    expression = input("Enter your sequence equation: ") #Space to enter equation
    iterations = int(input("Enter the number of iterations: ")) #Prompt for number of iterations
    a = float(input("Enter the initial value (a0): ")) #Prompt for intial value of a

    results = [a]  #Initializes result list with initial value of a
    for n in range(1, iterations + 1): #Loop until interation count is met
        a = evaluate_expression(expression, n, a) #Call evaluation for the equation
        if a is None: #If the evaluation doesn't work
            print("Terminating due to an error in the equation.")#Print error message
            break #Exit program
        results.append(a) #Add evaluations to results
    
    print("\nSequence Results:")
    for i, value in enumerate(results): #Loop until number of iterations is met
        print(f"a[{i}] = {value}") #Print sequence results

#Loop for main program
while True:
    menu() #Display the menu
    answer = input("\nEnter your choice: ").strip().upper() #Prompt user for choice from menu
    
    if answer == "R": #If R show rules
        rules()
    elif answer == "E": #If E, do equation and evaluate
        do()
    elif answer == "D": #If D, exit program
        break
    else: #Else, prompt user for a valid choice
        print("\nPlease enter a valid choice.")