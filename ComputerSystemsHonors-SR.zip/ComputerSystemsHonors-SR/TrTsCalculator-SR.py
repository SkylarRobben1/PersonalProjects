import matplotlib.pyplot as plt

#Create process class
class Process:
    #Default constructor of process object
    def __init__(self, pid, arrival_time, cpu_time):
        self.pid = pid #Process identifier for each object
        self.arrival_time = arrival_time #Arrival time of the process
        self.cpu_time = cpu_time #Amount of time process is on CPU
        self.remaining_time = cpu_time #Remaining time til completion of the process
        self.completion_time = 0 #Completion time of the process
        self.turnaround_time = 0 #Turnaround time of the process
        self.tr_ts = 0.0 #Tr/Ts of the process


#Function to get the input from the user and ensure a valid integer is inputted
def get_input():
    #Function to check if input is valid
    def get_valid_int(prompt):
        while True:
            try:
                value = int(input(prompt)) #Check to see if value is an integer
                if value < 0: #If value is negative
                    print("Please enter a non-negative integer.") #Print error message to user
                    continue
                return value
            except ValueError: #If value is not an integer
                print("Invalid input. Please enter an integer.") #Print error message to enter a valid integer

    #Initialize empty list of processes
    processes = []
    #Prompt user for number of processes
    n = get_valid_int("Enter the number of processes: ")
    #For i in range or # of processes
    for i in range(n):
        arrival_time = get_valid_int(f"Enter arrival time for process {i + 1}: ") #Prompt user for arrival time and check validity with get_valid_int
        cpu_time = get_valid_int(f"Enter CPU time for process {i + 1}: ") #Prompt user for process time and check validity with get_valid_int
        processes.append(Process(i + 1, arrival_time, cpu_time)) #Add new process object to the list and initialize with values of arrival time and process time

    #Prompt the user for a time quantam for Round Robin
    time_quantum = get_valid_int("\nEnter time quantum for Round Robin: ")
    return processes, time_quantum #Return list and integer for time quantum


#Sorting function to sort by arrival time
def sort_by_arrival(process):
    return process.arrival_time

#Sorting function to sort by CPU time
def sort_by_cpu_time(process):
    return process.cpu_time

#Sorting function to sort by remaining time
def sort_by_remaining_time(process):
    return process.remaining_time

#Function to calculate the scheduling based on First-Come-First-Serve
def calculate_fcfs(processes):
    processes.sort(key=sort_by_arrival) #Sort the list by process times
    current_time = 0 #Initialize the current time the CPU's are on
    for process in processes: #Process each process in order
        current_time = max(current_time, process.arrival_time) #Wait for process if needed
        process.completion_time = current_time + process.cpu_time #Caclulate completion time
        process.turnaround_time = process.completion_time - process.arrival_time #Calculate turnaround time
        process.tr_ts = process.turnaround_time / process.cpu_time #Solve for Tr/Ts
        current_time = process.completion_time #Current time is equal to the completion time of the process
    return processes

#Function to calculate the scheduling based on Shortest-Process-Next
def calculate_spn(processes):
    processes.sort(key=sort_by_arrival)  # Sort the list by arrival time
    current_time = 0 #Initialize the current time the CPU's are on
    remaining_processes = processes[:] #Copy processes to a seperate list
    completed_processes = [] #Lists of processes that have completed

    #While there is processes that need to be completed
    while remaining_processes:
        available_processes = [p for p in remaining_processes if p.arrival_time <= current_time] #Get the processes that are currently ready to go
        if available_processes:
            shortest_process = min(available_processes, key=sort_by_cpu_time) #Search for process with shortest cpu time
            remaining_processes.remove(shortest_process) #Remove from remaining processes list
            current_time = max(current_time, shortest_process.arrival_time) + shortest_process.cpu_time #Update the time
            shortest_process.completion_time = current_time #Update the completion time
            shortest_process.turnaround_time = shortest_process.completion_time - shortest_process.arrival_time #Update turnaround time
            shortest_process.tr_ts = shortest_process.turnaround_time / shortest_process.cpu_time #Calculate Tr/Ts
            completed_processes.append(shortest_process) #Add to completed processes list
        else:
            current_time += 1 #Increment time if no processes are ready
    return completed_processes

#Function to calculate the scheduling based on Shortest-Remaining-Time
def calculate_srt(processes):
    processes.sort(key=sort_by_arrival)  #Sort by arrival time
    current_time = 0 #Intialize time to 0
    remaining_processes = processes[:] #Copy processes to seperate list to keep track of remaining processes
    completed_processes = [] #List of completed processes

    #While there is processes that need to be completed
    while remaining_processes:
        available_processes = [p for p in remaining_processes if p.arrival_time <= current_time] #Get processes that are currently ready to go
        if available_processes: #If processes are available
            shortest_process = min(available_processes, key=sort_by_remaining_time) #Get the process with shortest time remaining
            shortest_process.remaining_time -= 1 #Subtract a time quantum from the remaining time
            current_time += 1 #Increment current time
            if shortest_process.remaining_time == 0: #If the process has no time remaining
                remaining_processes.remove(shortest_process) #Remove the process from the remaining process list
                shortest_process.completion_time = current_time #Update completion time
                shortest_process.turnaround_time = shortest_process.completion_time - shortest_process.arrival_time #Update turnaround time
                shortest_process.tr_ts = shortest_process.turnaround_time / shortest_process.cpu_time #Calculate the Tr/Ts of the process
                completed_processes.append(shortest_process) #Add process to completed processes list
        else:
            current_time += 1 #Increment time if no process is available
    return completed_processes

#Function to calculate the scheduling based on Round Robin
def calculate_rr(processes, time_quantum):
    processes.sort(key=sort_by_arrival)  #Sort by arrival time
    current_time = 0 #Initialize current time as 0
    ready_queue = [] #Create a ready queue to see if a process can be used
    remaining_processes = processes[:] #Create a copy of a list to keep track of remaining processes

    while remaining_processes or ready_queue: #Continue until all processes are processed
        while remaining_processes and remaining_processes[0].arrival_time <= current_time:
            ready_queue.append(remaining_processes.pop(0)) #Add all the processes that have arrived to ready queue

        if ready_queue: #If there are proceesses in ready queue
            process = ready_queue.pop(0) #Take the first process out of queue
            exec_time = min(process.remaining_time, time_quantum) #Execute the process for the time quantum
            process.remaining_time -= exec_time #Update remaining time
            current_time += exec_time #Update current time
            if process.remaining_time == 0: #If a process is complete
                process.completion_time = current_time #Update completion time
                process.turnaround_time = process.completion_time - process.arrival_time #Update turnaround time
                process.tr_ts = process.turnaround_time / process.cpu_time #Calculate and update Tr/Ts
            else:
                ready_queue.append(process) #If not, put the process back in the queue
        else:
            current_time += 1 #Increment current time
    return processes

#Function to plot the Tr/Ts values
#I used the following website to learn about the matplotlib library to be able to have the ability to plot the values
#https://www.geeksforgeeks.org/matplotlib-tutorial/
def plot_all_tr_ts(fcfs, spn, srt, rr):
    #Store the algorithm and there given results
    algorithms = {"FCFS": fcfs, "SPN": spn, "SRT": srt, "Round Robin": rr}

    #Create a 2x2 grid
    fig, axes = plt.subplots(2, 2, figsize=(14, 10))
    axes = axes.flatten() #flatten the axes

    #Iterate over the algorithms
    for ax, (name, processes) in zip(axes, algorithms.items()):
        pids = [p.pid for p in processes] #Get process Ids
        tr_ts_ratios = [p.tr_ts for p in processes] #Get Tr/Ts values

        #Plot the value
        ax.bar(pids, tr_ts_ratios, color='lightgreen', alpha=0.7) #Create bar plot
        ax.set_title(f"{name} - Tr/Ts Ratio") #Set the title of the graph
        ax.set_xlabel("Process ID") #Lable x axis with process ID
        ax.set_ylabel("Tr/Ts Ratio") #Lable y axis with Tr/Ts Value
        ax.set_xticks(pids) #Set x-axis ticks to pids

    plt.tight_layout() #Layout
    plt.show() #Show the plots

#Main function
def main():
    #Get input from the user
    processes, time_quantum = get_input()

    #Calculate the Tr/Ts for each scheduling algorithm
    fcfs_results = calculate_fcfs([Process(p.pid, p.arrival_time, p.cpu_time) for p in processes])
    spn_results = calculate_spn([Process(p.pid, p.arrival_time, p.cpu_time) for p in processes])
    srt_results = calculate_srt([Process(p.pid, p.arrival_time, p.cpu_time) for p in processes])
    rr_results = calculate_rr([Process(p.pid, p.arrival_time, p.cpu_time) for p in processes], time_quantum)

    #Plot the results
    plot_all_tr_ts(fcfs_results, spn_results, srt_results, rr_results)

#Execute the code
if __name__ == "__main__":
    main()
